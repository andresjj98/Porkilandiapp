export const initialCutTypes = {
  Res: ['Sirloin', 'Ribeye', 'T-Bone', 'Arrachera', 'Filete', 'Aguja'],
  Cerdo: ['Pierna', 'Espalda', 'Costilla', 'Lomo', 'Chuleta'],
  Pollo: ['Pechuga', 'Muslo', 'Pierna', 'Alas'],
  Otro: ['Corte Genérico'],
};