export const initialCarcasses = [
  {
    id: 'car-001',
    channelId: 'ch-001',
    entryDate: '2023-10-26',
    weight: 300,
    status: 'En Almacén',
  },
  {
    id: 'car-002',
    channelId: 'ch-002',
    entryDate: '2023-10-26',
    weight: 320,
    status: 'En Almacén',
  },
  {
    id: 'car-003',
    channelId: 'ch-003',
    entryDate: '2023-10-25',
    weight: 150,
    status: 'En Almacén',
  },
];