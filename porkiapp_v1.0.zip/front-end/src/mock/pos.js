export const initialPos = [
  { id: 'pos-001', name: 'Punto de Venta Centro', location: 'Calle Principal 123' },
  { id: 'pos-002', name: 'Punto de Venta Sur', location: 'Avenida Siempre Viva 456' },
];