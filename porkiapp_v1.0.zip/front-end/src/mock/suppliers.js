export const initialSuppliers = [
  { id: 'sup-001', name: 'Ganadería La Esperanza', contact: 'Juan Pérez', phone: '5512345678' },
  { id: 'sup-002', name: 'Distribuidora El Novillo', contact: 'María García', phone: '3398765432' },
  { id: 'sup-003', name: 'Carnes Finas del Norte', contact: 'Carlos López', phone: '8123456789' },
];